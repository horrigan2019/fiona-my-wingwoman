# Fiona: Your Wingwoman — Private Spa Suite

Live domain target: **fionamywingwoman.com** (Vercel)

## Local preview

```bash
python3 -m http.server 8080
```

Open `http://localhost:8080`.

## Deploy to Vercel + connect domain

### A. Deploy the site

1. Go to [vercel.com](https://vercel.com) and sign in (GitHub is easiest).
2. Click **Add New… → Project**.
3. Either:
   - **Import** a GitHub repo that contains this `index.html` + `assets/` folder, or
   - Use **CLI** from this project folder:
     ```bash
     npx vercel --prod
     ```
4. Framework preset: **Other** (static). Root directory = project root (where `index.html` lives).
5. Deploy. You’ll get a URL like `https://something.vercel.app`.

### B. Add fionamywingwoman.com

1. In the Vercel project → **Settings → Domains**.
2. Add:
   - `fionamywingwoman.com`
   - `www.fionamywingwoman.com` (optional but recommended)
3. Vercel will show the DNS records to add.

### C. DNS at your domain registrar

In the place you bought **fionamywingwoman.com**, add what Vercel shows. Typical setup:

| Type  | Name | Value                          |
|-------|------|--------------------------------|
| A     | `@`  | `76.76.21.21`                  |
| CNAME | `www`| `cname.vercel-dns.com`         |

(Use Vercel’s exact values if they differ.)

DNS can take a few minutes to a few hours. When Vercel shows the domain as **Valid**, open:

**https://fionamywingwoman.com**

### If the domain says “can’t be reached” or 404

Your DNS is already pointing at Vercel (`76.76.21.21`). That is not the problem.

The usual cause is **no production deployment** on the Vercel project that owns the domain (`DEPLOYMENT_NOT_FOUND`).

Fix it:

1. In Vercel, open the project that has `fionamywingwoman.com` under **Settings → Domains**.
2. Confirm the domain status is **Valid** (not just “Added”).
3. Go to the project **Deployments** tab.
4. If there is no successful **Production** deployment, deploy the site:
   - Import the GitHub repo that has `index.html` + `assets/`, **or**
   - From this folder on your computer: `npx vercel --prod`
5. After a green production deploy, wait 1–2 minutes and reload **https://fionamywingwoman.com**.

Also in GoDaddy: turn **off** Domain Forwarding / Website Builder parking so only the A/CNAME records above apply.

## Updating later

Change files → redeploy on Vercel (Git push or `npx vercel --prod`). Same domain, new version.

## Wings

1. **The Lounge** — affirmations, check-ins, Gentle Rituals, VIP key  
2. **The Sanctuary Suite** — diary + Perspective Mirror  
3. **The Calming Lagoon** — flare tracker, Feather Tiers, Yin, breath  
4. **Strut & Sweat** — mobility deck  
5. **The Glamour Suite** — wardrobe + hair/makeup canvases  
